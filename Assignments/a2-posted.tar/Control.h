#ifndef CONTROL_H
#define CONTROL_H


class Control
{
  public:

  private:

};

#endif
