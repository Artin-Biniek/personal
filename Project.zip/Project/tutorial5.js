var temp=document.getElementById("test");

temp.addEventListener('click',function(){
    this.style.fill="brown";
    
}, false);